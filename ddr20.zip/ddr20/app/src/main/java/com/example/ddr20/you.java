package com.example.ddr20;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class you extends Activity {

    EditText url;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_you);

        url = (EditText) findViewById(R.id.url);

        new Thread(new Runnable(){
            @Override
            public void run(){
                MysqlCon con = new MysqlCon();
                con.run();
                final String data = con.getData();
                Log.v("OK",data);
                url.post(new Runnable() {
                    public void run() {
                        url.setText(data);
                    }
                });

            }
        }).start();
        //Toast.makeText(getApplicationContext(),url.getText().toString(), Toast.LENGTH_LONG).show();
        //url.setText(urll);
    }

    void buttonOnClick(View view) {
        Toast toast = Toast.makeText(this,"開啟監控", Toast.LENGTH_SHORT);
        toast.show();

        Intent intent = new Intent();
        intent.setClass(you.this,page2.class);
        Bundle bundle = new Bundle();
        bundle.putString("url",url.getText().toString());
        intent.putExtras(bundle);   // 記得put進去，不然資料不會帶過去哦

        startActivity(intent);
    }
}
