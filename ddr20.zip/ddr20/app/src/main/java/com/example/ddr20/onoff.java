package com.example.ddr20;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;


public class onoff extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onoff);

    }

    void buttonOnClick(View view) {

        String topic        = "ddR20app";
        String content      = "111";
        int qos             = 2;
        String broker       = "tcp://broker.shiftr.io";
        String clientId     = "JavaSample";
        MemoryPersistence persistence = new MemoryPersistence();
        try {
            MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(false);
            connOpts.setUserName("ddR20ray");
            connOpts.setPassword("00000000".toCharArray());
            System.out.println("Connecting to broker: "+broker);
            sampleClient.setCallback(new MyMqttCallback());
            sampleClient.connect(connOpts);
            System.out.println("Connected");
            System.out.println("Publishing message: "+content);
            MqttMessage message = new MqttMessage(content.getBytes());
            message.setQos(qos);
            sampleClient.publish(topic, message);
            System.out.println("Message published");
            sampleClient.disconnect();
            System.out.println("Disconnected");
            /*System.exit(0);*/
        } catch(MqttException me) {
            System.out.println("reason "+me.getReasonCode());
            System.out.println("msg "+me.getMessage());
            System.out.println("loc "+me.getLocalizedMessage());
            System.out.println("cause "+me.getCause());
            System.out.println("excep "+me);
            me.printStackTrace();
        }



    }
    public class MyMqttCallback implements MqttCallback {
        @Override
        public void connectionLost(Throwable throwable) {
            Log.e("xxx", "connectionLost:" + throwable.getMessage());
        }

        @Override
        public void messageArrived(String s, MqttMessage mqttMessage) throws Exception {
            Log.e("xxx", "消息主题=" + s + "=======接收消息Qos=" + mqttMessage.getQos() + "=======接受消息内容=" + new String(mqttMessage.getPayload()));
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            Log.e("xxx", "deliveryComplete:" + iMqttDeliveryToken.isComplete());

        }
    }
}
