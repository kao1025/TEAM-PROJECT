package com.example.ddr20;

public class subjects implements Comparable<subjects>{
    public String SubjectName ;
    public String SubjectName2 ;
    public String category;
    public boolean isSectionHeader;
    /*public subjects(String Sname, String SFullForm) {

        super();

        this.SubjectName= Sname;

        this.SubjectName2 = SFullForm;
    }*/
    public subjects(String name, String category)
    {
        this.SubjectName = name;
        this.category = category;
        isSectionHeader = false;
    }
    public String getSubName() {

        return SubjectName;

    }
    public void setSubName(String code) {

        this.SubjectName = code;

    }
    public String getSubFullForm() {

        return SubjectName2;

    }
    public void setSubFullForm(String name) {

        this.SubjectName2 = name;
    }
    public String getCategory()
    {
        return category;
    }
    public void setToSectionHeader()
    {
        isSectionHeader = true;
    }

    public boolean isSectionHeader()
    {
        return isSectionHeader;
    }
    @Override
    public String toString() {

        return  SubjectName + " " + SubjectName2 ;

    }
    public int compareTo(subjects other) {
        return this.category.compareTo(other.category);
    }
}
