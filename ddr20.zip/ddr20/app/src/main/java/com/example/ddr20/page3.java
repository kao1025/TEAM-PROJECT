package com.example.ddr20;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class page3 extends AppCompatActivity {

    ListView SubjectListView;
    ProgressBar progressBarSubject;
    String ServerURL;
    SearchView searchView;
    String ss;
    ListAdapterClass adapter;

    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page3);
        Bundle bundle = getIntent().getExtras();
        ss = bundle.getString("url");
        if (ss.equals("test1")) ServerURL = "https://ddd300.000webhostapp.com/hello.php";
        else ServerURL = "https://ddd300.000webhostapp.com/hello1.php";
        SubjectListView = (ListView) findViewById(R.id.listview1);
        searchView = (SearchView)findViewById(R.id.searchView);
        progressBarSubject = (ProgressBar) findViewById(R.id.progressBar);
        searchView.setIconifiedByDefault(false);// 關閉icon切換
        searchView.setFocusable(false); // 不要進畫面就跳出輸入鍵盤
        setSearch_function();


        new GetHttpResponse(page3.this).execute();


    }

    private class GetHttpResponse extends AsyncTask<Void, Void, Void> {
        public Context context;

        String ResultHolder;

        ArrayList<subjects> subjectsList;

        public GetHttpResponse(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpServicesClass httpServiceObject = new HttpServicesClass(ServerURL);
            try {
                httpServiceObject.ExecutePostRequest();

                if (httpServiceObject.getResponseCode() == 200) {
                    ResultHolder = httpServiceObject.getResponse();

                    if (ResultHolder != null) {
                        JSONArray jsonArray = null;

                        try {
                            jsonArray = new JSONArray(ResultHolder);

                            JSONObject jsonObject;

                            subjects subjects;

                            subjectsList = new ArrayList<subjects>();

                            for (int i = 0; i < jsonArray.length(); i++) {
                                subjects = new subjects("","");

                                jsonObject = jsonArray.getJSONObject(i);

                                subjects.SubjectName = jsonObject.getString("time");
                                // subjectsList.add(subjects);
                                subjects.SubjectName2 = jsonObject.getString("id");
                                subjects.category = jsonObject.getString("time").substring(0, 10);
                                subjectsList.add(subjects);

                            }
                        } catch (JSONException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                } else {
                    Toast.makeText(context, httpServiceObject.getErrorMessage(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            progressBarSubject.setVisibility(View.GONE);

            SubjectListView.setVisibility(View.VISIBLE);
            subjectsList=sortAndAddSections(subjectsList);
            if (subjectsList != null) {
                adapter = new ListAdapterClass(subjectsList,R.layout.layout_items, context);
                SubjectListView.setAdapter(adapter);
                SubjectListView.setTextFilterEnabled(true);
                SubjectListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                        Intent intent = new Intent();
                        intent.setClass(page3.this, page2.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", adapter.valueList.get(arg2).SubjectName2);
                        intent.putExtras(bundle);   // 記得put進去，不然資料不會帶過去哦
                        startActivity(intent);
                        //Toast.makeText(page3.this,adapter.valueList.get(arg2).SubjectName2,Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
    }
    private ArrayList<subjects> sortAndAddSections(ArrayList<subjects> itemList)
    {

        ArrayList<subjects> tempList = new ArrayList<subjects>();
        //First we sort the array
        //Collections.sort(itemList);

        //Loops thorugh the list and add a section before each sectioncell start
        String header = "";
        for(int i = 0; i < itemList.size(); i++)
        {
            //If it is the start of a new section we create a new listcell and add it to our array
            if(!header.equals(itemList.get(i).getCategory())){
                subjects sectionCell = new subjects(itemList.get(i).getCategory(), null);
                sectionCell.setToSectionHeader();
                tempList.add(sectionCell);
                System.out.println(i  +header +  itemList.get(i).getCategory())  ;
                header = itemList.get(i).getCategory();

            }
            tempList.add(itemList.get(i));
        }

        return tempList;
    }
    private void setSearch_function() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);

                return true;
            }


        });
    }
}