package com.example.ddr20;

import android.os.Bundle;

import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

public class page2 extends Config {
    private YouTubePlayerView playerView;
    private String youtube_url;

    // IMPORTANT : CHANGE THIS
    String DEVELOPER_KEY = "AIzaSyCtUfnbtlHj1vI1ruRRAIYOS1MVCO9S1NE";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);
        Bundle bundle = getIntent().getExtras();
        String url = bundle.getString("url" );
        // The unique video id of the youtube video (can be obtained from video url)


                youtube_url = url ;


        playerView = (YouTubePlayerView) findViewById(R.id.player);
        playerView.initialize(DEVELOPER_KEY, this);



    }


    @Override
    protected YouTubePlayer.Provider getYouTubePlayerProvider() {
        return playerView;
    }

    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer player, boolean wasRestored) {

        player.setFullscreen(true);
        player.setShowFullscreenButton(false);
        player.setPlayerStyle(YouTubePlayer.PlayerStyle.DEFAULT);

        if (!wasRestored) {
            player.loadVideo(youtube_url);
        }

    }
}
