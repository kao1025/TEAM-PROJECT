package com.example.ddr20;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.Timer;

public class login extends Activity {
    String s="123";
    String url ;
    String test ;
    String val;
    String ss;
    int i=0;
    //String u1;
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }
    long[] vibrate = {0,100,200,300};

    private final Timer timer = new Timer();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Bundle bundle = getIntent().getExtras();
        ss = bundle.getString("url" );
        if(ss.equals("test1"))url = "https://ddd300.000webhostapp.com/not.php";
        else url= "https://ddd300.000webhostapp.com/not1.php";
        Intent intent = new Intent(this, MyService.class);
        this.startService(intent);

        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Create channel to show notifications.
            String channelId  = "default_notification_channel_id";
            String channelName = "default_notification_channel_name";
            NotificationManager notificationManager =
                    getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(new NotificationChannel(channelId,
                    channelName, NotificationManager.IMPORTANCE_LOW));
        }*/

        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            return;
                        }

                        if( task.getResult() == null)
                            return;
                        // Get new Instance ID token
                        String token = task.getResult().getToken();

                        // Log and toast
                        Log.i("login","token "+token);
                    }
                });

        if(ss.equals("test1"))sub();
        else unsub();
        //Notify();
        // Example of a call to a native method
    }
public void sub(){
    FirebaseMessaging.getInstance().subscribeToTopic("test1");
}
public void unsub(){
    FirebaseMessaging.getInstance().unsubscribeFromTopic("test1");
}

    void buttonOnClick(View view) {
        Toast toast = Toast.makeText(this, "開啟監控畫面", Toast.LENGTH_SHORT);
        toast.show();

        Intent intent = new Intent();
        intent.setClass(login.this , you.class);
        Bundle bundle = new Bundle();
        bundle.putString("url",s);
        intent.putExtras(bundle);
        startActivity(intent);

    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    void buttonOnClick1(View view) {
        Toast toast = Toast.makeText(this, "開啟歷史紀錄", Toast.LENGTH_SHORT);
        toast.show();
//Notify();
        Intent intent = new Intent();
        intent.setClass(login.this , page3.class);
        Bundle bundle = new Bundle();
        bundle.putString("url",ss);
        intent.putExtras(bundle);
        startActivity(intent);
    }
    void buttonOnClick2(View view) {
        Toast toast = Toast.makeText(this, "控制開關", Toast.LENGTH_SHORT);
        toast.show();
//Notify();
        Intent intent = new Intent();
        intent.setClass(login.this , onoff.class);
        Bundle bundle = new Bundle();
        bundle.putString("url",ss);
        intent.putExtras(bundle);
        startActivity(intent);
    }


}
