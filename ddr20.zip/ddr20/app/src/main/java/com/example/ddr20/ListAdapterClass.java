package com.example.ddr20;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ListAdapterClass extends ArrayAdapter<subjects> {

    Context context;
    public ArrayList <subjects> valueList;
    public ArrayList<subjects> SubjectListTemp;
    public ListAdapterClass.SubjectDataFilter subjectDataFilter ;

     LayoutInflater mLayout;
    public ListAdapterClass(List<subjects> listValue,int id, Context context) {
        super(context,id,listValue);
        mLayout = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        this.SubjectListTemp = new ArrayList<subjects>();

        this.SubjectListTemp.addAll(listValue);
        this.context = context;
        this.valueList= new ArrayList<subjects>();
        this.valueList.addAll(listValue);
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        /*ListAdapterClass.ViewItem holder=null;
        subjects cell = getItem(position);
        View v = convertView;
           if (convertView == null) {
                LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        convertView = vi.inflate(R.layout.layout_items, null);
                        holder = new ListAdapterClass.ViewItem();
                        holder.TextViewSubjectName = (TextView) convertView.findViewById(R.id.textView1);
                        holder.imageView = (ImageView) convertView.findViewById(R.id.imageView);
                    convertView.setTag(holder);
            }
            else {
                holder = (ListAdapterClass.ViewItem) convertView.getTag();
            }
        subjects subject = SubjectListTemp.get(position);
        holder.TextViewSubjectName.setText(subject.getSubName());
        Picasso.get().load("https://img.youtube.com/vi/"+subject.getSubFullForm()+"/hqdefault.jpg").into(holder.imageView);
       return convertView;*/
        View v = convertView;
        subjects cell = getItem(position);

        //If the cell is a section header we inflate the header layout
        if(cell.isSectionHeader())
        {
            v = mLayout.inflate(R.layout.section_header, null);
            v.setClickable(true);
            TextView header = (TextView) v.findViewById(R.id.section_header);
            header.setText(cell.getSubName());
        }
        else
        {
            v = mLayout.inflate(R.layout.layout_items, null);
            TextView name = (TextView) v.findViewById(R.id.textView1);
            ImageView imageView=(ImageView) v.findViewById(R.id.imageView);
            name.setText(cell.getSubName());
            Picasso.get().load("https://img.youtube.com/vi/"+cell.getSubFullForm()+"/hqdefault.jpg").into(imageView);

        }
        return v;
    }



    class ViewItem {
        TextView TextViewSubjectName;
        ImageView imageView;
        TextView header;
        //TextView TextViewSubjectName2;
    }


   // subjects subjects=new subjects();
    @Override
    public Filter getFilter() {
        if (subjectDataFilter == null){

            subjectDataFilter  = new ListAdapterClass.SubjectDataFilter();
        }
        return subjectDataFilter;
    }
    private class SubjectDataFilter extends Filter
    {

        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {

            charSequence = charSequence.toString().toLowerCase();

            FilterResults filterResults = new FilterResults();

            if(charSequence != null && charSequence.toString().length() > 0)
            {
                ArrayList<subjects> arrayList1 = new ArrayList<subjects>();

                for(int i = 0, l = valueList.size(); i < l; i++)
                {
                    subjects subject = valueList.get(i);

                    if(subject.toString().toLowerCase().contains(charSequence))

                        arrayList1.add(subject);
                }
                filterResults.count = arrayList1.size();

                filterResults.values = arrayList1;
            }
            else
            {
                synchronized(this)
                {
                    filterResults.values = valueList;

                    filterResults.count = valueList.size();
                }
            }
            return filterResults;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {

            SubjectListTemp = (ArrayList<subjects>)filterResults.values;



            notifyDataSetChanged();

            clear();

            for(int i = 0, l = SubjectListTemp.size(); i < l; i++)
                add(SubjectListTemp.get(i));

            notifyDataSetInvalidated();
        }
    }
}